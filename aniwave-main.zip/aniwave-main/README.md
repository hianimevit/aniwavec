# Introduction

This web app is a self-hosted version of the discontinued [aniwave.to](https://aniwave.to). It uses the same UI and provides the same UX as aniwave along with the ability to manage the media.
